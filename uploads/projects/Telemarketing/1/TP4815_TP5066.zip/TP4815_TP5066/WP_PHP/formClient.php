If(isset($_POST['Submit'])){
    global $wpdb;

    $companyName = $_POST['f_company'];
    $occupation  = $_POST['f_occupation'];
    $address     = $_POST['f_address'];
    $phone       = $_POST['f_phone'];
    $doy         = $_POST['f_doy'];
    $username    = $_POST['f_username'];
    $password    = $_POST['f_password'];

    $hash = password_hash($_POST["f_password"], PASSWORD_DEFAULT);

    if($wpdb->insert(
        'clients',
        array(
            'CompanyName' => $companyName,
            'Occupation'  => $occupation,
            'Address'     => $address,
            'Phone'       => $phone,
            'DOY'         => $doy,
            'Username'    => $username,
            'Password'    => $hash
        )
        ) == false) wp_die('DB Insertion Failed');
    else {
        ?>
		<div id="redirect">
			<button onclick = "location.href = 'http://localhost/TP4815'">  Return Home </button>
			<button onclick = "location.href = 'http://localhost/TP4815/create-client'"> Create More</button>
        </div>
		<?php
    }
    ?>
<?php
}else{
?>
    <form class="px-md-2" action="" method="post"  onsubmit="return validateForm()" id="clientForm">
        <div class="container">
            <div class="row">
                <div class="col-sm-4 sm-4">
                    <label class="form-label"> Company Name </label>           
                    <input type = "text" name = "f_company" class="form-control"/>         
                </div>
                <div class="col-sm-4 sm-4">
                    <label class="form-label"> Occupation </label>         
                    <input type = "text" name = "f_occupation" class="form-control"/>           
                </div>    
                <div class="col-sm-4 sm-4">
                    <label class="form-label"> Address  </label>           
                    <input type = "text" name = "f_address" class="form-control"/>           
                </div>
            </div>

            <div class="row">
                <div class="col-sm-6 sm-6">
                    <label class="form-label"> Phone </label>           
                    <input type = "text" name = "f_phone" class="form-control"/>         
                </div>
                <div class="col-sm-4 sm-4">
                    <label class="form-label"> DOY </label>         
                    <select id="doy_select" name = "f_doy" class="form-control">  
                    <option value=""> - </option>  
                    </select>        
                </div>    
            </div>

            <div class="row">
                <div class="col-sm-6 sm-6">
                    <label class="form-label"> Taxis Username </label>           
                    <input type = "text" name = "f_username" class="form-control"/>         
                </div>
                <div class="col-sm-4 sm-4">
                    <label class="form-label"> Password </label>         
                    <input type = "password" name = "f_password" class="form-control"/>           
                </div>    
            </div>
           
            <input type = "Submit" name="Submit" id="invoiceSubmit" value="Submit" />
    </form> 
<?php
}
?>
<script>
    let optionList = document.getElementById("doy_select").options;
    let options = [
        {text: "Agía Galíni" },{text: "Agía Marína" },{text: "AgíaVarvára" },{text: "ÁgioiDéka" },
        {text: "Ágios Nikólaos" },{text: "Ano Arhanes" },{text: "Anógeia" },{text: "Arkalochóri" },
        {text: "Asímion" },{text: "Atsipópoulo" },{text: "Chaniá" },{text: "Chóra Sfakíon" },
        {text: "Darátsos" },{text: "Eloúnda" },{text: "Galatás" },{text: "Gázi" },
        {text: "Georgioupolis" },{text: "Geráni" },{text: "Gérgeri" },{text: "Goúrnes" },
        {text: "Gra Liyiá" },{text: "Ierápetra" },{text: "Irákleion" },{text: "Kalýves" },
        {text: "Kastélli" },{text: "Kastrí" },{text: "Káto Asítai" },{text: "Káto Goúves" },
        {text: "Kentrí" },{text: "Kíssamos" },{text: "Kokkíni Cháni" },{text: "Kolympári" },
        {text: "Kritsá" },{text: "Krousón" },{text: "Limín Khersonísou" },{text: "Mália" },
        {text: "Moíres" },{text: "Mokhós" },{text: "Mourniés" }, {text: "Mouzourás" },
        {text: "Néa Alikarnassós" },{text: "Néa Anatolí" },{text: "Neápoli" },{text: "Nerokoúros" },
        {text: "Nomós Irakleíou" },{text: "Nomós Rethýmnis" },{text: "Palaióchora" },{text: "Palekastro" },
        {text: "Pánormos" },{text: "Pérama" },{text: "Perivólia" },{text: "Pithári" },
        {text: "Profítis Ilías" },{text: "Pýrgos" },{text: "Rethymno" },{text: "Schísma Eloúndas" },
        {text: "Sísion" },{text: "Sitia" },{text: "Skalánion" },{text: "Soúda" },
        {text: "Stalís" },{text: "Thrapsanón" },{text: "Tílisos" },{text: "Tsikalariá" },
        {text: "Tympáki" },{text: "Violí Charáki" },{text: "Vrýses" },{text: "Zarós" },{text: "Zonianá" } 
    ];
    options.forEach(option =>
        optionList.add(
            new Option(option.text, option.selected)
        )
    );    
</script>

<script>
    function validateForm() {

    let company  = document.forms["clientForm"]["f_company"].value;
    let occ      = document.forms["clientForm"]["f_occupation"].value;
    let address  = document.forms["clientForm"]["f_address"].value;
    let phone    = document.forms["clientForm"]["f_phone"].value;
    let doy      = document.forms["clientForm"]["f_doy"].value;
    let username = document.forms["clientForm"]["f_username"].value;
    let password = document.forms["clientForm"]["f_password"].value;

    if( company == "" || occ == "" || address == "" || 
        phone == "" || doy == "" || 
        username == "" || password == "" ) {
        alert("Please fill all of the Data");
        return false;
    }

    alert("Submited Successfully");

    } 
</script>

<style>
    .redirect{
        display: inline;
    }
    *{
        text-align: center;
    }
</style>