global $wpdb;


$result = $wpdb->get_results('SELECT CompanyName,Occupation,Username,Address,Phone FROM Clients');
if($result!=NULL){
    foreach($result as $row) {
        ?>
        <div class="card">
            <div class="content">
                <img src="https://i0.wp.com/ctmirror-images.s3.amazonaws.com/wp-content/uploads/2021/01/dummy-man-570x570-1.png?fit=570%2C570&ssl=1"
                    style="width:120px; height:120px;" >
                <div class="container">
                    <h3><p> <?php echo $row->CompanyName; ?> </p></h3>
                    <ul>
                        <li> <?php echo $row->Occupation;?> </li>
                        <li> <?php echo $row->Username;?>   </li>
                        <li> <?php echo $row->Address; ?>   </li>
                        <li> <?php echo $row->Phone; ?>     </li>
                    </ul>
                    </div>
            </div>
        </div>
        <?php
    }

}
?>

<style>
    .card {
        /* Add shadows to create the "card" effect */
        box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
        transition: 0.3s;
        margin-left: auto;
        margin-right: auto;
        width: 40%;
        display: inline-block;
    }
    .content{
        display: flex;
    }
    img{
        float: left;
    }

    .container{
        float: right;
        font-size: 12px;
    }

    /* On mouse-over, add a deeper shadow */
    .card:hover {
        box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);
    }

    /* Add some padding inside the card container */
    .container {
        padding: 2px 16px;
    }
</style>

<?php
?>