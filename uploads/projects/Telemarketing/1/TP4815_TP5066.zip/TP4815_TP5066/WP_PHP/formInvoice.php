If(isset($_POST['Submit'])){
    global $wpdb;

    $type          = $_POST['f_type'];
    $series        = $_POST['f_series'];
    $aa            = $_POST['f_aa'];
    $dateOfPublish = $_POST['f_dateOfPublish'];
    $client        = $_POST['f_client'];
    $vatNumber     = $_POST['f_vatNumber'];
    $department    = $_POST['f_department'];
    $deptCountry   = $_POST['f_deptCountry'];
    $clientStreet  = $_POST['f_clientStreet'];
    $clientCountry = $_POST['f_clientCountry'];
    $zipCode       = $_POST['f_zipCode'];
    $currency      = $_POST['f_currency'];
    $relatedInvoice= $_POST['f_relatedInvoice'];

    if($wpdb->insert(
        'invoices',
        array(
            'type'          => $type,
            'series'        => $series,
            'aa'            => $aa,
            'dateOfPublish' => $dateOfPublish,
            'client'        => $client,
            'vatNumber'     => $vatNumber,
            'department'    => $department,
            'deptCountry'   => $deptCountry,
            'clientStreet'  => $clientStreet,
            'clientCountry' => $clientCountry,
            'zipCode'       => $zipCode,
            'currency'      => $currency,
            'relatedInvoice'=> $relatedInvoice
        )
        ) == false) wp_die('DB Insertion Failed');
    else {
        ?>
		<div id="redirect">
			<button onclick = "location.href = 'http://localhost/TP4815'">  Return Home </button>
			<button onclick = "location.href = 'http://localhost/TP4815/create-invoice'"> Create More </button>
		</div>
        <?php
    }
}else{
?>
    <form class="px-md-2" action="" method="post"  onsubmit="return validateForm()" id="invoiceForm">
        <div class="container">
            <div class="row">
                <div class="col-sm-4 sm-4">
                    <label class="form-label"> Type </label>           
                    <input type = "text" name = "f_type" class="form-control"/>         
                </div>
                <div class="col-sm-4 sm-4">
                    <label class="form-label"> Series </label>         
                    <input type = "text" name = "f_series" class="form-control"/>           
                </div>    
                <div class="col-sm-4 sm-4">
                    <label class="form-label"> A/A  </label>           
                    <input type = "text" name = "f_aa" class="form-control"/>           
                </div>
            </div>
            <div class="row">
                <div class="col-sm-6 sm-6">
                    <label class="form-label"> Date Of Publish </label>
                    <input type = "date" name = "f_dateOfPublish" class="form-control"/>        
                </div>
                <div class="col-sm-6 sm-6">
                    <?php

                        global $wpdb;

                        
                        $result = $wpdb->get_results('SELECT CompanyName FROM Clients');
                        if($result!=NULL){
                            echo "<label class='form-label'>Client"; 
                            echo "<select name='f_client'>";
                            foreach($result as $row) {
                                echo "<option value='" .  $row->CompanyName . "'>" .  $row->CompanyName . "</option>";
                            }
                            echo "</select>";
                            echo "</label>";
                        }else{
                            echo "<label class='form-label'> Client </label> <input type = 'text' name = 'f_client' />";
                        }
                        
                        
                        ?>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-4 sm-4">
                    <label class="form-label"> VatNumber       </label>
                    <input type = "text" name = "f_vatNumber" class="form-control" />          
                </div>
                <div class="col-sm-4 sm-4">
                    <label class="form-label">  Department      </label>
                    <input type = "text" name = "f_department" class="form-control" />        
                </div>
                <div class="col-sm-4 sm-4">
                    <label class="form-label">  DeptCountry     </label>
                    <input type = "text" name = "f_deptCountry" class="form-control" />          
                </div>
            </div>
            <div class="row">
                <div class="col-sm-4 sm-4">
                    <label class="form-label">  Client Street   </label>
                    <input type = "text" name = "f_clientStreet" class="form-control" />         
                </div>
                <div class="col-sm-4 sm-4">
                    <label class="form-label">  Client Country  </label>
                    <input type = "text" name = "f_clientCountry" class="form-control" />        
                </div>
                <div class="col-sm-4 sm-4">
                    <label class="form-label">  Zip Code         </label>
                    <input type = "text" name = "f_zipCode" class="form-control" />             
                </div>
                </div>
            <div class="row">
                <div class="col-sm-6 sm-6">
                    <label class="form-label">  Currency      </label>
                    <input type = "text" name = "f_currency" />             
                </div>
                <div class="col-sm-6 sm-6">
                    <?php
                        global $wpdb;
                
                        $result = $wpdb->get_results('SELECT aa FROM Invoices');
                        if($result!=NULL){
                            echo "<label>Related Invoice"; 
                            echo "<select name='f_relatedInvoice'>";
                                echo "<option value='" .  '-' . "'>" .  '-' . "</option>";
                            foreach($result as $row) {
                                echo "<option value='" .  $row->aa . "'>" .  $row->aa . "</option>";
                            }
                            echo "</select>";
                            echo "</label>";
                        }else{
                            echo "<label> Related Invoice <input type = 'text' name = 'f_relatedInvoice'> </label>";
                        }
                        ?>
                </div>
            </div>
            <input type = "Submit" name="Submit" id="invoiceSubmit" value="Submit" />
    </form> 
<?php
}
?>
<script>

function validateForm() {

    let type          = document.forms["invoiceForm"]["f_type"].value;
    let series        = document.forms["invoiceForm"]["f_series"].value;
    let aa            = document.forms["invoiceForm"]["f_aa"].value;
    let dateOfPublish = document.forms["invoiceForm"]["f_dateOfPublish"].value;
   
    let vatNumber     = document.forms["invoiceForm"]["f_vatNumber"].value;
    let department    = document.forms["invoiceForm"]["f_department"].value;
    let deptCountry   = document.forms["invoiceForm"]["f_deptCountry"].value;

    let clientStreet  = document.forms["invoiceForm"]["f_clientStreet"].value;
    let clientCountry = document.forms["invoiceForm"]["f_clientCountry"].value;
    let zipCode       = document.forms["invoiceForm"]["f_zipCode"].value;
    let currency      = document.forms["invoiceForm"]["f_currency"].value;

    if( type == "" || series == "" || aa == "" || dateOfPublish == "" || vatNumber == "" || department == "" ||
        deptCountry == "" || clientStreet == "" || clientCountry == "" || zipCode == "" || currency =="") {
        alert("Please fill all of the Data");
        return false;
    }

    alert("Submited Successfully");

  } 

</script>
<style>
    .redirect{
        display: inline;
    }
    *{
        text-align: center;
    }
</style>