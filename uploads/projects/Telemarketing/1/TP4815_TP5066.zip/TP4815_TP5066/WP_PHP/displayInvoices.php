global $wpdb;

$result = $wpdb->get_results('SELECT * FROM invoices');
if($result!=NULL){
    foreach($result as $row) {
        ?>
        <div class="card">
            <div class="content">
                <img src="https://www.invoicesimple.com/wp-content/uploads/2018/06/Screen-Shot-2018-06-01-at-4.19.31-PM.png"
                    style="width:120px; height:120px;" >
                <div class="container">
                    <h3><p> <?php echo $row->type ." | " . $row->series . " | " . $row->aa;?> </p></h3>
                    <ul>
                        <li> <?php echo $row->dateOfPublish;?>     </li>
                        <li> <?php echo $row->client ."Vat: " . $row->vatNumber;?>     </li>
                        <li> <?php echo "Client: " . $row->clientStreet . " - " . $row->clientCountry; ?> </li>
                        <li> <?php echo "Department: " . $row->department . " - " . $row->deptCountry; ?> </li>
                        <li> <?php echo "Zip Code: " . $row->zipCode; ?> </li>
                        <li> <?php echo "Related Invoice: " . $row->relatedInvoice; ?> </li>
                    </ul>
                    </div>
            </div>
        </div>
        <?php
    }

}
?>

<style>
    .card {
        /* Add shadows to create the "card" effect */
        box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
        transition: 0.3s;
        margin-left: auto;
        margin-right: auto;
        width: 40%;
        display: inline-block;
    }
    .content{
        display: flex;
    }
    img{
        float: left;
    }

    .container{
        float: right;
        font-size: 12px;
    }

    /* On mouse-over, add a deeper shadow */
    .card:hover {
        box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);
    }

    /* Add some padding inside the card container */
    .container {
        padding: 2px 16px;
    }
</style>

<?php
?>