If(isset($_POST['Submit'])){
    global $wpdb;

    $type        = $_POST['f_type'];
    $category    = $_POST['f_category'];
    $codeUnit    = $_POST['f_codeUnit'];
    $description = $_POST['f_description'];
    $unitPrice   = $_POST['f_unitPrice'];
    $tax         = $_POST['f_tax'];
    $measureUnit = $_POST['f_measureUnit'];

    if($wpdb->insert(
        'products',
        array(
            'type'       => $type,
            'category'   => $category,
            'codeUnit'   => $codeUnit,
            'description'=> $description,
            'unitPrice'  => $unitPrice,
            'tax'        => $tax,
            'measureUnit'=> $measureUnit
        )
        ) == false) wp_die('DB Insertion Failed');
    else {
        ?>
		<div id = "redirect">
			<button onclick = "location.href = 'http://localhost/TP4815'">  Return Home </button>
			<button onclick = "location.href = 'http://localhost/TP4815/create-product'"> Create More </button>
		</div>
        
		<?php
    }
}else{
?>

    <form class="px-md-2" action="" method="post"  onsubmit="return validateForm()" id="productForm">
        <div class="container">
            <div class="row">
                <div class="col-sm-4 sm-4">
                    <label class="form-label"> Type </label>           
                    <input type = "text" name = "f_type" class="form-control"/>         
                </div>
                <div class="col-sm-4 sm-4">
                    <label class="form-label"> Category </label>         
                    <input type = "text" name = "f_category" class="form-control"/>           
                </div>    
                <div class="col-sm-4 sm-4">
                    <label class="form-label"> CodeUnit  </label>           
                    <input type = "text" name = "f_codeUnit" class="form-control"/>           
                </div>
            </div>

            <div class="row">
                <div class="col-md-12 md-12">
                    <label class="form-label"> Description </label>         
                    <input type = "text" name = "f_description" class="form-control"/>           
                </div>    
            </div>

            <div class="row">
                <div class="col-sm-6 sm-6">
                    <label class="form-label"> Unit Price </label>           
                    <input type = "text" name = "f_unitPrice" class="form-control"/>         
                </div>
                <div class="col-sm-4 sm-4">
                    <label class="form-label"> Tax </label>         
                    <input type = "text" name = "f_tax" class="form-control"/>           
                </div>    
                <div class="col-sm-4 sm-4">
                    <label class="form-label"> Measure Unit </label>       
					<select name='f_measureUnit' class="form-control">
					<option value='per unit'> Per Unit </option>
					<option value='per dozen'>Per Dozen </option>
                    </select>
                </div>   
            </div>

           
            <input type = "Submit" name="Submit" id="invoiceSubmit" value="Submit" />
    </form> 



<?php
}
?>

<script>

function validateForm() {

    let type        = document.forms["productForm"]["f_type"].value;
    let category    = document.forms["productForm"]["f_category"].value;
    let codeUnit    = document.forms["productForm"]["f_codeUnit"].value;
    let description = document.forms["productForm"]["f_description"].value;
   
    let unitPrice   = document.forms["productForm"]["f_unitPrice"].value;
    let tax         = document.forms["productForm"]["f_tax"].value;
    let measureUnit = document.forms["productForm"]["f_measureUnit"].value;

    if( type == "" || category == "" || codeUnit == "" || 
        description == "" || unitPrice == "" || 
        tax == "" || measureUnit == "" ) {
        alert("Please fill all of the Data");
        return false;
    }

    alert("Submited Successfully");

  } 

</script>
	
<style>
    .redirect{
        display: inline;
    }
    *{
        text-align: center;
    }
</style>