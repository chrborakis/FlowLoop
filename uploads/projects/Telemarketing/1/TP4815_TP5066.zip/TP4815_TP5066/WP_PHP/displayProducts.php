global $wpdb;


$result = $wpdb->get_results('SELECT type,category,codeUnit,description,unitPrice,measureUnit FROM products');
if($result!=NULL){
    foreach($result as $row) {
        ?>
        <div class="card">
            <div class="content">
                <img src="https://hinacreates.com/wp-content/uploads/2021/06/dummy2.png"
                    style="width:120px; height:120px;" >
                <div class="container">
                    <h3><p> <?php echo $row->type; ?> </p></h3>
                    <ul>
                        <li> <?php echo $row->category;?>     </li>
                        <li> <?php echo $row->codeUnit;?>     </li>
                        <li> <?php echo $row->description;?>  </li>
                        <li> <?php echo $row->unitPrice . " /" . $row->measureUnit; ?> </li>
                    </ul>
                    </div>
            </div>
        </div>
        <?php
    }

}
?>

<style>
    .card {
        /* Add shadows to create the "card" effect */
        box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
        transition: 0.3s;
        margin-left: auto;
        margin-right: auto;
        width: 40%;
        display: inline-block;
    }
    .content{
        display: flex;
    }
    img{
        float: left;
    }

    .container{
        float: right;
        font-size: 12px;
    }

    /* On mouse-over, add a deeper shadow */
    .card:hover {
        box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);
    }

    /* Add some padding inside the card container */
    .container {
        padding: 2px 16px;
    }
</style>

<?php
?>